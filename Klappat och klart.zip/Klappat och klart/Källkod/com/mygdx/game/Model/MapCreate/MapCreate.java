package com.mygdx.game.Model.MapCreate;

import java.util.ArrayList;

public class MapCreate {
	public ArrayList<BrickCreate> bricks;
	
	public MapCreate(){
		this.bricks = new ArrayList<BrickCreate>();
	}
}

package com.mygdx.game.Model.Entities;

public class Wall {

}

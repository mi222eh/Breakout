package com.mygdx.game.interfaces;

public interface GameContactContactListener {

}
